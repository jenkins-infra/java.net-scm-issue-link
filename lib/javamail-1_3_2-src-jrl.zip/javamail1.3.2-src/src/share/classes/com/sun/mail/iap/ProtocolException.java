/*
 * @(#)ProtocolException.java	1.5 02/03/27
 *
 * Copyright 1997-2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

/**
 * @author John Mani
 */

public class ProtocolException extends Exception {
    protected Response response = null;

    /**
     * Constructs a ProtocolException with no detail message.
     */
    public ProtocolException() {
	super();
    }

    /**
     * Constructs a ProtocolException with the specified detail message.
     * @param s		the detail message
     */
    public ProtocolException(String s) {
	super(s);
    }

    /**
     * Constructs a ProtocolException with the specified Response object.
     */
    public ProtocolException(Response r) {
	super(r.toString());
	response = r;
    }

    /**
     * Return the offending Response object.
     */
    public Response getResponse() {
	return response;
    }
}
