/*
 * @(#)text_xml.java	1.2 02/03/27
 *
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.handlers;

import javax.activation.ActivationDataFlavor;

/**
 * DataContentHandler for text/xml.
 *
 * @version 1.2, 02/03/27
 */
public class text_xml extends text_plain {
    private static ActivationDataFlavor myDF = new ActivationDataFlavor(
	java.lang.String.class,
	"text/xml",
	"XML String");

    protected ActivationDataFlavor getDF() {
	return myDF;
    }
}
