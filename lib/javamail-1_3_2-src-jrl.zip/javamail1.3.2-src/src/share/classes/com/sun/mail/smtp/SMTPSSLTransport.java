/*
 * @(#)SMTPSSLTransport.java	1.1 04/05/11
 *
 * Copyright 1997-2004 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.smtp;

import javax.mail.*;

/**
 * This class implements the Transport abstract class using SMTP
 * over SSL for message submission and transport.
 *
 * @author Bill Shannon
 */

public class SMTPSSLTransport extends SMTPTransport {

    /** Constructor */
    public SMTPSSLTransport(Session session, URLName urlname) {
	super(session, urlname, "smtps", 465, true);
    }
}
