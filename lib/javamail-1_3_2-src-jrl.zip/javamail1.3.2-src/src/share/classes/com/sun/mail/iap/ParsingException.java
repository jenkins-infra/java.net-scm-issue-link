/*
 * @(#)ParsingException.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

/**
 * @author John Mani
 */

public class ParsingException extends ProtocolException {

    /**
     * Constructs an ParsingException with no detail message.
     */
    public ParsingException() {
	super();
    }

    /**
     * Constructs an ParsingException with the specified detail message.
     * @param s		the detail message
     */
    public ParsingException(String s) {
	super(s);
    }

    /**
     * Constructs an ParsingException with the specified Response.
     * @param r		the Response
     */
    public ParsingException(Response r) {
	super(r);
    }
}
