/*
 * @(#)SocketFetcher.java	1.15 04/08/16
 *
 * Copyright 1998-2004 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.util;

import java.net.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.Properties;

/**
 * This class is used to get Sockets. Depending on the arguments passed
 * it will either return a plain java.net.Socket or dynamically load
 * the SocketFactory class specified in the classname param and return
 * a socket created by that SocketFactory.
 *
 * @author Max Spivak
 * @author Bill Shannon
 */
public class SocketFetcher implements Runnable {
    private Socket socket;
    private String host;
    private int port;
    private Properties props;
    private String prefix;
    private int cto;			// connection timeout
    private boolean useSSL;
    private IOException exception;
    private boolean aborted = false; // tells connection thread to close socket
    private boolean done = false;	// run method has completed

    // the standard SSL socket factory, referenced via reflection
    private static final String SSL_SOCKET_FACTORY =
					"javax.net.ssl.SSLSocketFactory";
    private static final String SSL_SOCKET = "javax.net.ssl.SSLSocket";

    private SocketFetcher(String host, int port, Properties props,
				String prefix, int cto, boolean useSSL)
				throws IOException {
	this.host = host;
	this.port = port;
	this.props = props;
	this.prefix = prefix;
	this.cto = cto;
	this.useSSL = useSSL;
    }

    /**
     * This method returns a Socket.  Properties control the use of
     * socket factories and other socket characteristics.  The properties
     * used are: <p>
     * <ul>
     * <li> <i>prefix</i>.socketFactory.class
     * <li> <i>prefix</i>.socketFactory.fallback
     * <li> <i>prefix</i>.socketFactory.port
     * <li> <i>prefix</i>.timeout
     * <li> <i>prefix</i>.connectiontimeout
     * <li> <i>prefix</i>.localaddress
     * <li> <i>prefix</i>.localport
     * </ul> <p>
     * If the socketFactory.class property isn't set, the socket
     * returned is an instance of java.net.Socket connected to the
     * given host and port. If the socketFactory.class property is set,
     * it is expected to contain a fully qualified classname of a
     * javax.net.SocketFactory subclass.  In this case, the class is
     * dynamically instantiated and a socket created by that
     * SocketFactory is returned. <p>
     *
     * If the socketFactory.fallback property is set to false, don't
     * fall back to using regular sockets if the socket factory fails. <p>
     *
     * The socketFactory.port specifies a port to use when connecting
     * through the socket factory.  If unset, the port argument will be
     * used.  <p>
     *
     * If the connectiontimeout property is set, we use a separate thread
     * to make the connection so that we can timeout that connection attempt.
     * <p>
     *
     * If the timeout property is set, it is used to set the socket timeout.
     * <p>
     *
     * If the localaddress property is set, it's used as the local address
     * to bind to.  If the localport property is also set, it's used as the
     * local port number to bind to.
     *
     * @param host The host to connect to
     * @param port The port to connect to at the host
     * @param props Properties object containing socket properties
     * @param prefix Property name prefix, e.g., "mail.imap"
     * @param useSSL use the SSL socket factory as the default
     */
    public static Socket getSocket(String host, int port, Properties props,
				String prefix, boolean useSSL)
				throws IOException {

	if (prefix == null)
	    prefix = "socket";
	if (props == null)
	    props = new Properties();	// empty
	String s = props.getProperty(prefix + ".connectiontimeout", null);
	int cto = -1;
	if (s != null) {
	    try {
		cto = Integer.parseInt(s);
	    } catch (NumberFormatException nfex) { }
	}
	if (cto > 0) {
	    SocketFetcher sf =
		    new SocketFetcher(host, port, props, prefix, cto, useSSL);
	    try {
		Thread t = new Thread(sf, "Connection thread for host " + host);
		t.start();
	    } catch (Exception ex) {
		/*
		 * Can't create a thread, perhaps because we're in a J2EE
		 * container.  Just do all the work in this thread.
		 */
		return getSocket0(host, port, props, prefix, useSSL);
	    }
	    return sf.getSocket();
	} else
	    return getSocket0(host, port, props, prefix, useSSL);
    }

    public static Socket getSocket(String host, int port, Properties props,
				String prefix) throws IOException {
	return getSocket(host, port, props, prefix, false);
    }

    /**
     * Start TLS on an existing socket.
     * Supports the "STARTTLS" command in many protocols.
     */
    public static Socket startTLS(Socket socket) throws IOException {
	InetAddress a = socket.getInetAddress();
	String host = a.getHostName();
	int port = socket.getPort();
//System.out.println("SocketFetcher: startTLS host " + host + ", port " + port);

	try {
	    String sfClass;
	    try {
		sfClass = System.getProperty("mail.SSLSocketFactory.class",
						SSL_SOCKET_FACTORY);
	    } catch (SecurityException sex) {
		sfClass = SSL_SOCKET_FACTORY;
	    }
	    Class clsSockFact = Class.forName(sfClass);
	    // get & invoke the getDefault() method
	    Method mthGetDefault = clsSockFact.getMethod("getDefault", 
							 new Class[]{});
	    Object o = mthGetDefault.invoke(new Object(), new Object[]{});
	    // get & invoke the createSocket() method
	    // createSocket(Socket s, String host, int port, boolean autoClose)
	    Class[] mthArgs = new Class[] {
				    java.net.Socket.class,
				    java.lang.String.class, 
				    Integer.TYPE,
				    Boolean.TYPE
				    };
	    Method mthCreateSocket = 
		clsSockFact.getMethod("createSocket", mthArgs);
	    Object[] crSockArgs = new Object[] {
			    socket, host, new Integer(port), Boolean.TRUE };
	    socket = (Socket)mthCreateSocket.invoke(o, crSockArgs);
	    // All the above to do...
	    // socket = SSLSocketFactory.getDefault().
	    // 				createSocket(socket, host, port, true);

	    /*
	     * At least the UW IMAP server insists on only the TLSv1
	     * protocol for STARTTLS, and won't accept the old SSLv2
	     * or SSLv3 protocols.  Here we enable only the TLSv1
	     * protocol.  XXX - this should probably be parameterized.
	     */
	    // get & invoke the setEnabledProtocols() method
	    Class clsSSLSocket = Class.forName(SSL_SOCKET);
	    try {
		Method mthSetEnabledProtocols =
				clsSSLSocket.getMethod("setEnabledProtocols", 
				    new Class[]{ String[].class });
		if (mthSetEnabledProtocols != null)
		    mthSetEnabledProtocols.invoke(socket, new Object[] {
				    new String[] { "TLSv1" }
				    });
	    } catch (NoSuchMethodException nsm) {
		// ignore it and hope it still works;
		// method doesn't exist before J2SE 1.4
	    }
	    // All the above to do...
	    // ((SSLSocket)socket).setEnabledProtocols(new String[] {"TLSv1"});
	} catch (Exception ex) {
	    if (ex instanceof InvocationTargetException) {
		Throwable t =
		  ((InvocationTargetException)ex).getTargetException();
		if (t instanceof Exception)
		    ex = (Exception)t;
	    }
	    if (ex instanceof IOException)
		throw (IOException)ex;
	    // wrap anything else before sending it on
	    // XXX - chain exception
	    throw new IOException("Exception in startTLS: host " + host +
				", port " + port + "; Exception: " + ex);
	}
	return socket;
    }

    /**
     * This method deals with all the hard work of handling the socket
     * factory class, and then making the connection.  Note that to
     * avoid a static dependency on the javax.net.SocketFactory class
     * we use reflection to invoke the socket factory.
     */
    private static Socket getSocket0(String host, int port, Properties props,
				String prefix, boolean useSSL)
				throws IOException {
	Socket socket = null;
	String sfClass =
	    props.getProperty(prefix + ".socketFactory.class", null);
	String timeout = props.getProperty(prefix + ".timeout", null);
	String localaddrstr = props.getProperty(prefix + ".localaddress", null);
	InetAddress localaddr = null;
	if (localaddrstr != null)
	    localaddr = InetAddress.getByName(localaddrstr);
	String localportstr = props.getProperty(prefix + ".localport", null);
	int localport = 0;
	if (localportstr != null) {
	    try {
		localport = Integer.parseInt(localportstr);
	    } catch (NumberFormatException nfex) { }
	}

	boolean usingDefaultFactory = false;
	if ((sfClass == null || sfClass.length() <= 0) && useSSL) {
	    try {
		sfClass = System.getProperty("mail.SSLSocketFactory.class",
						SSL_SOCKET_FACTORY);
	    } catch (SecurityException sex) {
		sfClass = SSL_SOCKET_FACTORY;
	    }
	    usingDefaultFactory = true;
	}
	if (sfClass == null || sfClass.length() <= 0) {
	    // get a regular socket
	    socket = new Socket(host, port, localaddr, localport);
	} else {
	    // dynamically load the class 
	    int sfPort = -1;
	    boolean fb = false;
	    if (!usingDefaultFactory) {
		String fallback =
		    props.getProperty(prefix + ".socketFactory.fallback", null);
		fb = fallback == null || (!fallback.equalsIgnoreCase("false"));
		String sfPortStr =
		    props.getProperty(prefix + ".socketFactory.port", null);
		if (sfPortStr != null) {
		    try {
			sfPort = Integer.parseInt(sfPortStr);
		    } catch (NumberFormatException nfex) { }
		}
	    }

	    try {
		Class clsSockFact = Class.forName(sfClass);
		// get & invoke the getDefault() method
		Method mthGetDefault = clsSockFact.getMethod("getDefault", 
							     new Class[]{});
		Object o = mthGetDefault.invoke(new Object(), new Object[]{});
		// if port passed in via property is valid, use it
		Integer portInt = new Integer(sfPort != -1 ? sfPort : port);
		/*
		 * XXX - should be able to use the first case below even when
		 * localaddr is null, but user-written socket factories might
		 * not handle this case properly so take the safe approach
		 * and use the most appropriate method.
		 */
		if (localaddr != null) {
		    // get & invoke the createSocket() method
		    Class[] mthArgs = new Class[] {
						java.lang.String.class, 
						Integer.TYPE,
						InetAddress.class,
						Integer.TYPE
						};
		    Method mthCreateSocket = 
			clsSockFact.getMethod("createSocket", mthArgs);
		    Object[] crSockArgs = new Object[] {
						host,
						portInt,
						localaddr,
						new Integer(localport)
						};
		    socket = (Socket) mthCreateSocket.invoke(o, crSockArgs);
		} else {
		    // get & invoke the createSocket() method
		    Class[] mthArgs = new Class[] { java.lang.String.class, 
						    Integer.TYPE };
		    Method mthCreateSocket = 
			clsSockFact.getMethod("createSocket", mthArgs);
		    Object[] crSockArgs = new Object[] { host, portInt };
		    socket = (Socket) mthCreateSocket.invoke(o, crSockArgs);
		}
	    } catch (Exception ex) {
		if (fb) {
		    socket = new Socket(host, port, localaddr, localport);
		} else {
		    if (ex instanceof InvocationTargetException) {
			Throwable t =
			  ((InvocationTargetException)ex).getTargetException();
			if (t instanceof Exception)
			    ex = (Exception)t;
		    }
		    if (ex instanceof IOException)
			throw (IOException)ex;
		    throw new IOException("Couldn't connect using \"" +
					  sfClass + 
					  "\" socket factory to host, port: " +
					  host + ", " + sfPort +
					  "; Exception: " + ex);
		}
	    }
	}	    

	int to = -1;
	if (timeout != null) {
	    try {
		to = Integer.parseInt(timeout);
	    } catch (NumberFormatException nfex) { }
	}
	if (to >= 0)
	    socket.setSoTimeout(to);

	return socket;
    }

    /**
     * Wait until the other thread has created the socket, or
     * our timeout has expired, and then return the results.
     * Note that this method should only be called once.
     */
    private synchronized Socket getSocket() throws IOException {
	if (!done) {
	    try {
		long now = System.currentTimeMillis();
		long deadline = now + cto;
		while (now < deadline) {
		    wait(deadline - now);
		    if (done)	// if we're all done, get out of here!
			break;
		    // We may've been woken up because we exceeded the timeout,
		    // or we may've been woken up spuriously.  Update the
		    // current time to see if we need to continue waiting.
		    now = System.currentTimeMillis();
		}
	    } catch (InterruptedException ex) {
		exception = new InterruptedIOException(ex.toString());
	    }
	}
	if (exception != null) {
	    aborted = true;
	    throw exception;
	}
	if (socket == null) {
	    aborted = true;
	    throw new ConnectException("connection to " + host + " timed out");
	}
	Socket s = socket;
	socket = null;	// so finalizer won't close
	return s;
    }

    /**
     * Try to open the connection, and only when done
     * synchronize with the main "getSocket" thread and
     * return our result.
     */
    public void run() {
	try {
	    Socket s = getSocket0(host, port, props, prefix, useSSL);
	    synchronized (this) {
		if (aborted) {
		    // getSocket thread gave up waiting,
		    // we have to close the socket
		    try {
			s.close();
		    } catch (IOException ex) { }
		} else
		    socket = s;
		done = true;
		notify();	// wakeup getSocket thread
	    }
	} catch (IOException ex) {
	    synchronized (this) {
		exception = ex;	// record failure
		done = true;
		notify();	// wakeup getSocket thread
	    }
	}
    }

    protected synchronized void finalize() throws Throwable {
	/*
	 * Paranoia.  This should never happen, but just
	 * in case we get here without the socket being
	 * closed, close it.
	 */
	super.finalize();
	if (socket != null)
	    socket.close();	// just in case
    }
}
