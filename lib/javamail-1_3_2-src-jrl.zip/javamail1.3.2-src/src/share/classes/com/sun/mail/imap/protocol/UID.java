/*
 * @(#)UID.java	1.4 02/03/27
 *
 * Copyright 1998, 1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.imap.protocol;

import com.sun.mail.iap.*; 

/**
 * This class represents the UID data item
 *
 * @version 1.4, 02/03/27
 * @author  John Mani
 */

public class UID implements Item {
    
    public final static char [] name = {'U','I','D'};
    public int msgno;

    public long uid;

    /**
     * Constructor
     */
    public UID(FetchResponse r) throws ParsingException {
	msgno = r.getNumber();
	r.skipSpaces();
	uid = r.readLong();
    }
}
