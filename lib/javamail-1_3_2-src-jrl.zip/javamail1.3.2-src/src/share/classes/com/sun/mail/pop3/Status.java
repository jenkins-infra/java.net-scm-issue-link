/*
 *  @(#)Status.java	1.1 04/07/15
 *
 * Copyright 1997-2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 *
 */

package com.sun.mail.pop3;

/**
 * Result of POP3 STAT command.
 */
class Status {
    int total = 0;		// number of messages in the mailbox
    int size = 0;		// size of the mailbox
};
