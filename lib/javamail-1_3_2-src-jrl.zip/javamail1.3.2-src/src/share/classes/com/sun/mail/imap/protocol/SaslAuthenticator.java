/*
 * @(#)SaslAuthenticator.java	1.2 04/08/06
 *
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ProtocolException;

/**
 * Interface to make it easier to call IMAPSaslAuthenticator.
 */

public interface SaslAuthenticator {
    public boolean authenticate(String[] mechs, String realm, String authzid,
				String u, String p) throws ProtocolException;

}
