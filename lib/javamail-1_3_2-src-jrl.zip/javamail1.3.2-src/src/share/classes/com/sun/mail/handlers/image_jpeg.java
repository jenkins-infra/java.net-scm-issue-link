/*
 * @(#)image_jpeg.java	1.1 02/05/23
 *
 * Copyright 1997-2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.handlers;

import java.awt.datatransfer.DataFlavor;
import javax.activation.*;

/**
 * DataContentHandler for image/jpeg.
 */
public class image_jpeg extends image_gif {
    private static ActivationDataFlavor myDF = new ActivationDataFlavor(
	java.awt.Image.class,
	"image/jpeg",
	"JPEG Image");

    protected ActivationDataFlavor getDF() {
	return myDF;
    }
}
