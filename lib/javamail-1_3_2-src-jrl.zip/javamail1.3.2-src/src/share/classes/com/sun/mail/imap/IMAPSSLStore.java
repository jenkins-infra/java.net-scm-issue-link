/*
 * @(#)IMAPSSLStore.java	1.1 04/05/11
 *
 * Copyright 1997-2004 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.imap;

import javax.mail.*;

/**
 * This class provides access to an IMAP message store over SSL. <p>
 */

public class IMAPSSLStore extends IMAPStore {
    
    /**
     * Constructor that takes a Session object and a URLName that
     * represents a specific IMAP server.
     */
    public IMAPSSLStore(Session session, URLName url) {
	super(session, url, "imaps", 993, true); // call super constructor
    }
}
