/*
 * @(#)IMAPMultipartDataSource.java	1.5 02/04/02
 *
 * Copyright 1997-2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.imap;

import java.io.InputStream;
import java.io.IOException;
import java.util.Vector;

import javax.mail.*;
import javax.mail.internet.*;

import com.sun.mail.util.*;
import com.sun.mail.iap.*;
import com.sun.mail.imap.protocol.*;

/**
 * This class 
 *
 * @version 1.5, 02/04/02
 * @author  John Mani
 */

public class IMAPMultipartDataSource extends MimePartDataSource
				     implements MultipartDataSource {
    private Vector parts;

    protected IMAPMultipartDataSource(MimePart part, BODYSTRUCTURE[] bs, 
				      String sectionId, IMAPMessage msg) {
	super(part);

	parts = new Vector(bs.length);
	for (int i = 0; i < bs.length; i++)
	    parts.addElement(
		new IMAPBodyPart(bs[i], 
				 sectionId == null ? 
				   Integer.toString(i+1) : 
				   sectionId + "." + Integer.toString(i+1),
				 msg)
	    );
    }

    public int getCount() {
	return parts.size();
    }

    public BodyPart getBodyPart(int index) throws MessagingException {
	return (BodyPart)parts.elementAt(index);
    }
}
