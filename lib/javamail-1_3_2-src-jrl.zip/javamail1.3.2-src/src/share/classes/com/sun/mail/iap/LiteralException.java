/*
 * @(#)LiteralException.java	1.2 02/03/27
 *
 * Copyright 2002 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

/**
 * @author Bill Shannon
 */

public class LiteralException extends ProtocolException {

    /**
     * Constructs a LiteralException with the specified Response object.
     */
    public LiteralException(Response r) {
	super(r.toString());
	response = r;
    }
}
