/*
 * @(#)Literal.java	1.2 02/03/27
 *
 * Copyright 2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

import java.io.*;

/**
 * An interface for objects that provide data dynamically for use in
 * a literal protocol element.
 *
 * @version 1.2, 02/03/27
 * @author  Bill Shannon
 */

public interface Literal {
    /**
     * Return the size of the data.
     */
    public int size();

    /**
     * Write the data to the OutputStream.
     */
    public void writeTo(OutputStream os) throws IOException;
}
