/*
 * @(#)POP3SSLStore.java	1.1 04/05/11
 *
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 *
 */

package com.sun.mail.pop3;

import javax.mail.*;

/**
 * A POP3 Message Store using SSL.  Contains only one folder, "INBOX".
 *
 * @author      Bill Shannon
 */
public class POP3SSLStore extends POP3Store {

    public POP3SSLStore(Session session, URLName url) {
	super(session, url, "pop3s", 995, true);
    }
}
