/*
 * @(#)text_html.java	1.1 99/12/16
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package com.sun.mail.handlers;

import javax.activation.ActivationDataFlavor;

/**
 * DataContentHandler for text/html.
 *
 * @version 1.1, 99/12/16
 */
public class text_html extends text_plain {
    private static ActivationDataFlavor myDF = new ActivationDataFlavor(
	java.lang.String.class,
	"text/html",
	"HTML String");

    protected ActivationDataFlavor getDF() {
	return myDF;
    }
}
