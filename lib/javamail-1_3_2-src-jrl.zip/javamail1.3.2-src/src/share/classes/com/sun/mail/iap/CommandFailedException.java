/*
 * @(#)CommandFailedException.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

/**
 * @author John Mani
 */

public class CommandFailedException extends ProtocolException {

    /**
     * Constructs an CommandFailedException with no detail message.
     */
    public CommandFailedException() {
	super();
    }

    /**
     * Constructs an CommandFailedException with the specified detail message.
     * @param s		the detail message
     */
    public CommandFailedException(String s) {
	super(s);
    }

    /**
     * Constructs an CommandFailedException with the specified Response.
     * @param r		the Response.
     */
    public CommandFailedException(Response r) {
	super(r);
    }
}
