/*
 * @(#)ResponseHandler.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.iap;

/**
 * This class 
 *
 * @version 1.1, 97/11/10
 * @author  John Mani
 */

public interface ResponseHandler { 
    public void handleResponse(Response r);
}
