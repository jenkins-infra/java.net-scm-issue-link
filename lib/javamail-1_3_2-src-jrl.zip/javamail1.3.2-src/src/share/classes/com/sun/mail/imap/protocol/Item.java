/*
 * @(#)Item.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package com.sun.mail.imap.protocol;

/**
 * A tagging interface for all IMAP data items.
 * Note that the "name" field of all IMAP items MUST be in uppercase.
 *
 * @version 1.4, 02/03/27
 * @author  John Mani
 * @see BODY, BODYSTRUCTURE, ENVELOPE, FLAGS, INTERNALDATE, RFC822DATA,
 *	RFC822SIZE, UID
 */

public interface Item { 
}
