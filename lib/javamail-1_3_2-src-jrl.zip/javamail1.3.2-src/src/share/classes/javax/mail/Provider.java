/*
 * @(#)Provider.java	1.8 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail;

/**
 * The Provider is a class that describes a protocol 
 * implementation. The values come from the
 * javamail.providers & javamail.default.providers
 * resource files.
 *
 * @version 1.8, 02/03/27
 * @author Max Spivak
 */
public class Provider {

    /**
     * This inner class defines the Provider type.
     * Currently, STORE and TRANSPORT are the only two provider types 
     * supported.
     */

    public static class Type {
	public static final Type STORE     = new Type("Store");
	public static final Type TRANSPORT = new Type("Transport");

	private String type;

	private Type(String type) {
	    this.type = type;
	}
    }

    private Type type;
    private String protocol, className, vendor, version;

    /**
     * Package-private constructor for the Provider class.
     *
     * @param type      Type.STORE or Type.TRANSPORT
     * @param protocol  valid protocol for the type
     * @param classname class name that implements this protocol
     * @param vendor    optional string identifying the vendor (may be null)
     * @param version   optional implementation version string (may be null)
     */
    Provider(Type type, String protocol, String classname, 
	     String vendor, String version) {
	this.type = type;
	this.protocol = protocol;
	this.className = classname;
	this.vendor = vendor;
	this.version = version;
    }

    /** Returns the type of this Provider */
    public Type getType() {
	return type;
    }

    /** Returns the protocol supported by this Provider */
    public String getProtocol() {
	return protocol;
    }

    /** Returns name of the class that implements the protocol */
    public String getClassName() {
	return className;
    }

    /** Returns name of vendor associated with this implementation or null */
    public String getVendor() {
	return vendor;
    }

    /** Returns version of this implementation or null if no version */
    public String getVersion() {
	return version;
    }

    /** Overrides Object.toString() */
    public String toString() {
	String s = "javax.mail.Provider[";
	if (type == Type.STORE) {
	    s += "STORE,";
	} else if (type == Type.TRANSPORT) {
	    s += "TRANSPORT,";
	}

	s += protocol + "," + className;

	if (vendor != null)
	    s += "," + vendor;

	if (version != null)
	    s += "," + version;

	s += "]";
	return s;
    }
}
