/*
 * @(#)MailEvent.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.EventObject;

/**
 * Common base class for mail events, defining the dispatch method.
 *
 * @author Bill Shannon
 */

public abstract class MailEvent extends EventObject {
    public MailEvent(Object source) {
        super(source);
    }

    /**
     * This method invokes the appropriate method on a listener for
     * this event. Subclasses provide the implementation.
     */
    public abstract void dispatch(Object listener);
}
