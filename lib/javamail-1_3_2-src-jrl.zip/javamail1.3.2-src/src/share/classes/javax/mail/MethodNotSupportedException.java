/*
 * @(#)MethodNotSupportedException.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail;


/**
 * The exception thrown when a method is not supported by the 
 * implementation
 *
 * @author John Mani
 */

public
class MethodNotSupportedException extends MessagingException {
    /**
     * Constructs a MethodNotSupportedException with no detail message.
     */
    public MethodNotSupportedException() {
	super();
    }

    /**
     * Constructs a MethodNotSupportedException with the specified detail message.
     * @param s		the detail message
     */
    public MethodNotSupportedException(String s) {
	super(s);
    }
}
