/*
 * @(#)NotTerm.java	1.7 02/03/27
 *
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.search;

import javax.mail.Message;

/**
 * This class implements the logical NEGATION operator.
 *
 * @author Bill Shannon
 * @author John Mani
 */
public final class NotTerm extends SearchTerm {
    /**
     * The search term to negate.
     *
     * @serial
     */
    protected SearchTerm term;

    public NotTerm(SearchTerm t) {
	term = t;
    }

    /**
     * Return the term to negate.
     */
    public SearchTerm getTerm() {
	return term;
    }

    /* The NOT operation */
    public boolean match(Message msg) {
	return !term.match(msg);
    }

    /**
     * Equality comparison.
     */
    public boolean equals(Object obj) {
	if (!(obj instanceof NotTerm))
	    return false;
	NotTerm nt = (NotTerm)obj;
	return nt.term.equals(this.term);
    }

    /**
     * Compute a hashCode for this object.
     */
    public int hashCode() {
	return term.hashCode() << 1;
    }
}
