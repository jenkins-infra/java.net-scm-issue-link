/*
 * @(#)MessageCountAdapter.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

/**
 * The adapter which receives MessageCount events.
 * The methods in this class are empty;  this class is provided as a
 * convenience for easily creating listeners by extending this class
 * and overriding only the methods of interest.
 *
 * @author John Mani
 */
public abstract class MessageCountAdapter implements MessageCountListener {
    public void messagesAdded(MessageCountEvent e) {}
    public void messagesRemoved(MessageCountEvent e) {}
}
