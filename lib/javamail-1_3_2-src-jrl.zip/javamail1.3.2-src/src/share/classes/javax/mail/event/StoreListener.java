/*
 * @(#)StoreListener.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for Store Notifications.
 *
 * @author John Mani
 */

public interface StoreListener extends java.util.EventListener {

   /**
    * Invoked when the Store generates a notification event.
    *
    * @see StoreEvent#ALERT
    * @see StoreEvent#NOTICE
    */
   public void notification(StoreEvent e);
}
