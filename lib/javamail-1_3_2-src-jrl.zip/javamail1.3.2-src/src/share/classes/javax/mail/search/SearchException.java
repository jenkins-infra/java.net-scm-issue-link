/*
 * @(#)SearchException.java	1.6 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.search;

import javax.mail.MessagingException;


/**
 * The exception thrown when a Search expression could not be handled.
 *
 * @author John Mani
 */

public class SearchException extends MessagingException {

    /**
     * Constructs a SearchException with no detail message.
     */
    public SearchException() {
	super();
    }

    /**
     * Constructs a SearchException with the specified detail message.
     * @param s		the detail message
     */
    public SearchException(String s) {
	super(s);
    }
}
