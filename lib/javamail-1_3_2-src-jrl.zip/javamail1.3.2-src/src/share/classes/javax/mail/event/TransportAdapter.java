/*
 * @(#)TransportAdapter.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

/**
 * The adapter which receives Transport events.
 * The methods in this class are empty;  this class is provided as a
 * convenience for easily creating listeners by extending this class
 * and overriding only the methods of interest.
 *
 * @author John Mani
 */
public abstract class TransportAdapter implements TransportListener {
    public void messageDelivered(TransportEvent e) {}
    public void messageNotDelivered(TransportEvent e) {}
    public void messagePartiallyDelivered(TransportEvent e) {}
}
