/*
 * @(#)TransportListener.java	1.6 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for Transport events
 *
 * @author John Mani
 * @author Max Spivak
 *
 * @see javax.mail.Transport
 * @see javax.mail.event.TransportEvent
 */

public interface TransportListener extends java.util.EventListener {

    /**
     * Invoked when a Message is succesfully delivered.
     * @param	e TransportEvent
     */
    public void messageDelivered(TransportEvent e);

    /**
     * Invoked when a Message is not delivered.
     * @param	e TransportEvent
     * @see TransportEvent
     */
    public void messageNotDelivered(TransportEvent e);

    /**
     * Invoked when a Message is partially delivered.
     * @param	e TransportEvent
     * @see TransportEvent
     */
    public void messagePartiallyDelivered(TransportEvent e);
}
