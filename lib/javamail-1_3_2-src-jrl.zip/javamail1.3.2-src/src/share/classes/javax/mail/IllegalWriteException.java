/*
 * @(#)IllegalWriteException.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail;


/**
 * The exception thrown when a write is attempted on a read-only attribute
 * of any Messaging object. 
 *
 * @author John Mani
 */

public
class IllegalWriteException extends MessagingException {

    /**
     * Constructs a IllegalWriteException with no detail message.
     */
    public IllegalWriteException() {
	super();
    }

    /**
     * Constructs a IllegalWriteException with the specified detail message.
     * @param s		the detail message
     */
    public IllegalWriteException(String s) {
	super(s);
    }
}
