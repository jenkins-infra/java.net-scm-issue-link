/*
 * @(#)FolderListener.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for Folder events.
 *
 * @author John Mani
 */

public interface FolderListener extends java.util.EventListener {
    /**
     * Invoked when a Folder is created.
     */
    public void folderCreated(FolderEvent e);

    /**
     * Invoked when a folder is deleted.
     */
    public void folderDeleted(FolderEvent e);

    /**
     * Invoked when a folder is renamed.
     */
    public void folderRenamed(FolderEvent e);
}
