/*
 * @(#)MessageAware.java	1.4 02/03/27
 *
 * Copyright 1998, 1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */
/*
 * @(#)MessageAware.java	1.4 02/03/27
 *
 * Copyright (c) 1998 by Sun Microsystems, Inc.
 * All Rights Reserved.
 */

package javax.mail;

/**
 * An interface optionally implemented by <code>DataSources</code> to
 * supply information to a <code>DataContentHandler</code> about the
 * message context in which the data content object is operating.
 *
 * @see javax.mail.MessageContext
 * @see javax.activation.DataSource
 * @see javax.activation.DataContentHandler
 * @since	JavaMail 1.1
 */
public interface MessageAware {
    /**
     * Return the message context.
     */
    public MessageContext getMessageContext();
}
