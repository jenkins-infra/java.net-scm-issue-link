/*
 * @(#)RecipientTerm.java	1.8 02/03/27
 *
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.search;

import javax.mail.Message;
import javax.mail.Address;

/**
 * This class implements comparisons for the Recipient Address headers.
 *
 * @author Bill Shannon
 * @author John Mani
 */
public final class RecipientTerm extends AddressTerm {

    /**
     * The recipient type.
     *
     * @serial
     */
    protected Message.RecipientType type;

    /**
     * Constructor.
     *
     * @param type	the recipient type
     * @param address	the address to match for
     */
    public RecipientTerm(Message.RecipientType type, Address address) {
	super(address);
	this.type = type;
    }

    /**
     * Return the type of recipient to match with.
     */
    public Message.RecipientType getRecipientType() {
	return type;
    }

    /**
     * The match method.
     *
     * @param msg	The address match is applied to this Message's recepient
     *			address
     * @return		true if the match succeeds, otherwise false
     */
    public boolean match(Message msg) {
	Address[] recipients;

	try {
 	    recipients = msg.getRecipients(type);
	} catch (Exception e) {
	    return false;
	}

	if (recipients == null)
	    return false;

	for (int i=0; i < recipients.length; i++)
	    if (super.match(recipients[i]))
		return true;
	return false;
    }

    /**
     * Equality comparison.
     */
    public boolean equals(Object obj) {
	if (!(obj instanceof RecipientTerm))
	    return false;
	RecipientTerm rt = (RecipientTerm)obj;
	return rt.type.equals(this.type) && super.equals(obj);
    }

    /**
     * Compute a hashCode for this object.
     */
    public int hashCode() {
	return type.hashCode() + super.hashCode();
    }
}
