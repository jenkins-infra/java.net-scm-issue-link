/*
 * @(#)MessageChangedListener.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for MessageChanged events
 *
 * @author John Mani
 */

public interface MessageChangedListener extends java.util.EventListener {
    /**
     * Invoked when a message is changed. The change-type specifies
     * what changed.
     * @see MessageChangedEvent#FLAGS_CHANGED
     * @see MessageChangedEvent#ENVELOPE_CHANGED
     */
    public void messageChanged(MessageChangedEvent e);
}
