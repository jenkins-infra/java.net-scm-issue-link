/*
 * @(#)NoSuchProviderException.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail;

/**
 * This exception is thrown when Session attempts to instantiate a  
 * Provider that doesn't exist.
 * 
 * @author Max Spivak
 */

public class NoSuchProviderException extends MessagingException {
    
    /**
     * Constructor.
     */
    public NoSuchProviderException() {
	super();
    }

    /**
     * Constructor.
     * @param message	The detailed error message
     */
    public NoSuchProviderException(String message) {
	super(message);
    }
}
