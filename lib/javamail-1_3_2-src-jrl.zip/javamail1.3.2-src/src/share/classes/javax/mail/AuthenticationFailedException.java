/*
 * @(#)AuthenticationFailedException.java	1.3 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail;

/**
 * This exception is thrown when the connect method on a Store or
 * Transport object fails due to an authentication failure (e.g.,
 * bad user name or password).
 *
 * @author Bill Shannon
 */

public class AuthenticationFailedException extends MessagingException {

    /**
     * Constructor
     */
    public AuthenticationFailedException() {
	super();
    }

    /**
     * Constructor
     * @param message	The detailed error message
     */
    public AuthenticationFailedException(String message) {
	super(message);
    }
}
