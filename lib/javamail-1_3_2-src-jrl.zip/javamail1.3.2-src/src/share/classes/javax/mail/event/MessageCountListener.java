/*
 * @(#)MessageCountListener.java	1.4 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for MessageCount events.
 *
 * @author John Mani
 */

public interface MessageCountListener extends java.util.EventListener {
    /**
     * Invoked when messages are added into a folder.
     */
    public void messagesAdded(MessageCountEvent e);

    /**
     * Invoked when messages are removed (expunged) from a folder.
     */
    public void messagesRemoved(MessageCountEvent e);
}
