/*
 * @(#)ConnectionListener.java	1.5 02/03/27
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN PROPRIETARY/CONFIDENTIAL.  Use is subject to license terms.
 * 
 */

package javax.mail.event;

import java.util.*;

/**
 * This is the Listener interface for Connection events.
 *
 * @author John Mani
 */

public interface ConnectionListener extends java.util.EventListener {

    /**
     * Invoked when a Store/Folder/Transport is opened.
     */
    public void opened(ConnectionEvent e);

    /**
     * Invoked when a Store is disconnected. Note that a folder
     * cannot be disconnected, so a folder will not fire this event
     */
    public void disconnected(ConnectionEvent e);

    /**
     * Invoked when a Store/Folder/Transport is closed.
     */
    public void closed(ConnectionEvent e);
}
